// Secure Password Manager
// Author: Wesley Attram

#include <iostream>
#include <fstream>
#include <string>
#include <map>

using namespace std;

void savePassword(const string& site, const string& password) {
    ofstream file("passwords.txt", ios::app);
    file << site << " " << password << endl;
    file.close();
}

string retrievePassword(const string& site) {
    ifstream file("passwords.txt");
    string s, p;
    while (file >> s >> p) {
        if (s == site) {
            return p;
        }
    }
    return "Not Found";
}

int main() {
    int choice;
    string site, password;
    
    cout << "1. Save Password\n2. Retrieve Password\nEnter choice: ";
    cin >> choice;
    
    if (choice == 1) {
        cout << "Enter site: ";
        cin >> site;
        cout << "Enter password: ";
        cin >> password;
        savePassword(site, password);
        cout << "Saved successfully!\n";
    } else if (choice == 2) {
        cout << "Enter site: ";
        cin >> site;
        cout << "Password: " << retrievePassword(site) << endl;
    }
    
    return 0;
}
